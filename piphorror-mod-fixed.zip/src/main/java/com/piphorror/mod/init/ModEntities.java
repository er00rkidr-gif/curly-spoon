package com.piphorror.mod.init;

import com.piphorror.mod.PipHorrorMod;
import com.piphorror.mod.entity.PipChatListener;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
        DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, PipHorrorMod.MOD_ID);

    public static final RegistryObject<EntityType<PipChatListener>> PIP = ENTITIES.register(
        "pip",
        () -> EntityType.Builder.of(PipChatListener::new, MobCategory.CREATURE)
            .sized(0.75F, 1.30F)
            .build(new ResourceLocation(PipHorrorMod.MOD_ID, "pip").toString())
    );
}
