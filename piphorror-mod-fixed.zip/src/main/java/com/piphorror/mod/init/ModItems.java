package com.piphorror.mod.init;

import com.piphorror.mod.PipHorrorMod;
import com.piphorror.mod.storyline.UnknownCorpseItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
        DeferredRegister.create(ForgeRegistries.ITEMS, PipHorrorMod.MOD_ID);

    public static final RegistryObject<Item> PIP_SPAWN_EGG = ITEMS.register(
        "pip_spawn_egg",
        () -> new ForgeSpawnEggItem(ModEntities.PIP, 0x9AD3C0, 0x9B8BB8, new Item.Properties())
    );

    /** Storyline item: found in chests. Placing it sets down a motionless Pip that wakes when fed an axolotl. */
    public static final RegistryObject<Item> UNKNOWN_CORPSE = ITEMS.register(
        "unknown_corpse",
        () -> new UnknownCorpseItem(new Item.Properties().stacksTo(1).rarity(Rarity.UNCOMMON))
    );
}
